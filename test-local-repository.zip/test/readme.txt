youtube video: https://www.youtube.com/watch?v=Y9XZQO1n_7c

change 1
change 2
change 3

Added index.html

you first need to add new files to your repository: 
git add readme.txt

you can see the current files status via:
git status

Now you will see that readme.txt is both staged and undstaged.
If you commit now, you will only have the file state when you added it to git.
You will lose any new changes on that file from that point.
To fix this and track the current file changes, you simply re-add the file:
git add readme.txt


If you have multiple changes, you just add them all:
git add *

Or just the extensions:
git add *.html

If we want to exclude certain files, for example *.log files, we can create a .gitignore file
in which we specify names and patterns for git to ignore when we do git add *
The .gitignore file will be committed and part of our branch.


Branching and merging:
First you need to create your branch, where you will do your changes:
git branch MyBranch

Now you need to switch to your new branch. You do this using:
git checkout MyBranch

After you add your changes and commit, you can return to the original branch
git checkout master

Note: master is always the main branch!

Now we are going to merge the branches:
We have our changes in MyBranch and we want to get those changes on the master branch.
Before you merge, make sure you are on the DESTINATION branch! In our case, we are on master.

When you actually do the merge, you might have merge conflicts! They will be added in your
files using <<<HEAD and ========== markers. After you fix or do the merges, you commit once more.

If you merge changes from the master branch to your branch, you will see such conflicts:
<<<<<<<< HEAD
change from your branch
========
change from the master branch
>>>>>>>> master



You can commit and add the changes to staged files in the same time with the -a option:
git commit -a -m 'Merges done'

Note: Any new files that are not tracked will not be added! You will need to add them manually
using the git add . command

Merging an actual project is extremely laborious if you just rely on the CLI, so you can
install and setup git to use a Mergetool. Then when you have merge conflicts, just run:
git mergetool




If you make changes and do not commit them, for example you are not ready to commit your
changes to your branch, but you need to switch branches for a bugfix or something,
then you can save your currently 'dirty' version of your branch by stashing it.
Track your changes using
git add .

Now just stash your changes so you may checkout the other branch:
git statsh

Now you git status will show there are no changes pending. Do the checkout and you're fine.
After you've done your changes on the other branch, return (checkout) to this one
and re-apply the stashed changes using:
git stash apply



Remote repositories:

View all remote repositories:
git remote

Clone remote repository:
git clone https://github.com/GSerea/test.git

You may view your remote repository status (fromn your repository) via:
git remote

View the push and fetch links:
git remote -v


Get any new changes since your last clone or fetch:
git fetch origin 

If you use git fetch, it will not merge the changes. You will need to merge manually.
You can use git pull to automatically fetch and MERGE the latest changes in your branch:
git pull origin

When you commit, you actually commit locally:
git commit -a -m "Adding my changes"

When you want to submit your commit to the remote repository, just use:
git push origin master

The above command means: "push my changes to the remote repository known to us as origin and commit to the master branch"


















>>>>>>> MyBranch

